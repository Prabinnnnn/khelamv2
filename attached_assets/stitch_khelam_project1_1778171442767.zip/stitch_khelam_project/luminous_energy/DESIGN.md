---
name: Luminous Energy
colors:
  surface: '#fafbe8'
  surface-dim: '#dadbca'
  surface-bright: '#fafbe8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f5e3'
  surface-container: '#eeefdd'
  surface-container-high: '#e8ead8'
  surface-container-highest: '#e2e4d2'
  on-surface: '#1a1d12'
  on-surface-variant: '#444935'
  inverse-surface: '#2f3226'
  inverse-on-surface: '#f1f2e0'
  outline: '#757963'
  outline-variant: '#c5c9af'
  surface-tint: '#506600'
  primary: '#506600'
  on-primary: '#ffffff'
  primary-container: '#c8f248'
  on-primary-container: '#556d00'
  inverse-primary: '#add52b'
  secondary: '#5e6052'
  on-secondary: '#ffffff'
  secondary-container: '#e3e4d2'
  on-secondary-container: '#646658'
  tertiary: '#515f77'
  on-tertiary: '#ffffff'
  tertiary-container: '#d4e3ff'
  on-tertiary-container: '#56657d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c8f248'
  primary-fixed-dim: '#add52b'
  on-primary-fixed: '#161f00'
  on-primary-fixed-variant: '#3c4d00'
  secondary-fixed: '#e3e4d2'
  secondary-fixed-dim: '#c7c8b7'
  on-secondary-fixed: '#1b1d12'
  on-secondary-fixed-variant: '#46483b'
  tertiary-fixed: '#d4e3ff'
  tertiary-fixed-dim: '#b8c7e2'
  on-tertiary-fixed: '#0c1c30'
  on-tertiary-fixed-variant: '#39475e'
  background: '#fafbe8'
  on-background: '#1a1d12'
  surface-variant: '#e2e4d2'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  h1:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  h2:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  h3:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  gutter: 20px
  margin: 24px
---

## Brand & Style

This design system is built on a foundation of **Modern Minimalism** infused with high-energy accents. It targets a dynamic, forward-thinking audience that values clarity and speed. The visual narrative centers on "Airy Vibrancy"—utilizing expansive whitespace to let the content breathe, while using sharp, electric highlights to guide the eye and inject personality. 

The aesthetic is characterized by flat surfaces, generous padding, and a sophisticated interplay between neutral foundations and high-visibility interaction points. It avoids heavy gradients and complex shadows in favor of structural clarity and typographic excellence.

## Colors

The palette is anchored by a crisp White (#FFFFFF) foundation to maximize light and space. Surfaces utilize a subtle Light Grey (#F1F3F5) to provide a soft distinction between the background and interactive containers without adding visual weight.

The **Electric Lime (#C8F248)** serves as the high-voltage primary accent. To maintain accessibility, this color must always be paired with Dark Charcoal (#12140A) text when used as a background for buttons or chips. For secondary information and metadata, the Softer Grey (#5F6368) provides a legible yet understated contrast against the bright background.

## Typography

The design system exclusively utilizes **Plus Jakarta Sans** to leverage its friendly, rounded terminals and high legibility. The typographic scale is designed for impact, with heavy weights for headlines to create a strong vertical rhythm. 

Body text is set with generous line heights to ensure long-form content feels approachable and easy to scan. Labels and small captions use a slightly tighter letter-spacing and increased font weight to maintain authority at smaller scales.

## Layout & Spacing

This design system employs a **Fluid Grid** model with a base-4 spacing rhythm. Layouts should utilize a 12-column grid for desktop and a 4-column grid for mobile devices. 

The spacing philosophy emphasizes "Negative Space as a Feature." Generous margins (24px+) around primary containers prevent the UI from feeling cluttered. Elements within components (like icons and text in a card) should follow the 8px or 16px steps to maintain a mathematical harmony across the interface.

## Elevation & Depth

To maintain an "airy" feel, this design system moves away from traditional heavy shadows. Instead, it uses **Tonal Layering** and **Low-Contrast Outlines**.

1.  **Level 0 (Background):** Pure White (#FFFFFF).
2.  **Level 1 (Surfaces):** Light Grey (#F1F3F5) used for cards and inset sections to create subtle depth.
3.  **Interactive States:** Elements that require a "lift" (like hovered cards) should use a very soft, highly diffused ambient shadow: `0px 10px 30px rgba(18, 20, 10, 0.04)`.
4.  **Borders:** Use a 1px solid border (#E9ECEF) for form inputs and structural dividers to provide definition without breaking the clean aesthetic.

## Shapes

The shape language is defined by the **16px (1rem) base radius**, which provides a soft, approachable character. 

-   **Primary Components:** Buttons, Cards, and Modals all share the 16px radius for visual consistency.
-   **Small Components:** Tags and Chips may use a fully rounded "pill" shape to distinguish them from actionable buttons.
-   **Inner Radii:** When nesting elements, ensure the inner radius is smaller (typically 8px or 12px) to maintain concentric visual alignment.

## Components

### Buttons
-   **Primary:** Background: Electric Lime (#C8F248), Text: Dark Charcoal (#12140A), Weight: Bold.
-   **Secondary:** Background: Dark Charcoal (#12140A), Text: White (#FFFFFF).
-   **Ghost:** Transparent background, Dark Charcoal text, 1px border (#E9ECEF).

### Input Fields
-   Background: #F8F9FA, Border: 1px #F1F3F5, Radius: 16px. On focus, the border shifts to Dark Charcoal or Electric Lime.

### Cards
-   Background: #FFFFFF, Padding: 24px, Radius: 16px. Use a subtle 1px border (#F1F3F5) rather than a shadow to define the perimeter.

### Chips & Tags
-   Used for categorization. Use the Surface color (#F1F3F5) as the background with Secondary Text (#5F6368).

### Navigation
-   Navigation bars should remain pure White (#FFFFFF) with a thin bottom border of #F1F3F5 to ensure they feel "floating" and light. Active links are denoted by an Electric Lime dot or underline.